#!/bin/sh

cd ${HOME}/configurator
java -jar ./target/mdsConfigurator-1.0.0.jar
